class Config :
    AWS_ACCESS_KEY = 'AKIAYS2NUHPTXLY34ICE'
    AWS_SECRET_ACCESS_KEY = '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'

    S3_BUCKET = 'project-rekognition-yh'
    S3_URL = 'https://project-rekognition-yh.s3.ap-northeast-2.amazonaws.com/'